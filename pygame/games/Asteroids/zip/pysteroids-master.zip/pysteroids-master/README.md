# pysteroids
Old shool style asteroids game made with Python - Pygame

Main file to execute is 'asteroids.py'

Made using Python 3.5 and Pygame 1.9.2
