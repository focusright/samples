# flappy

## flappy001.py

- part 1: background and flappy jumps https://wp.me/papz4L-1Q2

- part 2: animation https://wp.me/papz4L-1Q8


Launch *flappy6.py* for the last version.

Flappy7.py is an experiment with different graphic.

<img src="https://i0.wp.com/pythonprogramming.altervista.org/wp-content/uploads/2020/09/flappy6-1.png?resize=676%2C483&ssl=1" />

https://youtu.be/2CvLlGmCx_A
