
Flappy Bird in Pygame! - 2019 / 02 / 09

Created by Carter Jean

Made with Python 3.7.1 and of course, Pygame

Press space to start the game and to fly.
